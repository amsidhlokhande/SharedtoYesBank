using System;
using System.Collections;
using System.Data;
using OutSystems.HubEdition.RuntimePlatform;

namespace OutSystems.NssAmazon_EC2_Utilities {

	public interface IssAmazon_EC2_Utilities {

		/// <summary>
		/// 
		/// </summary>
		/// <param name="ssAccessKey"></param>
		/// <param name="ssSecretKey"></param>
		/// <param name="ssAmiId"></param>
		/// <param name="ssInstanceTypeName"></param>
		/// <param name="ssKeyName"></param>
		/// <param name="ssSecurityGroupId"></param>
		/// <param name="ssRegion"></param>
		/// <param name="ssInstanceTagName"></param>
		/// <param name="ssInstanceId"></param>
		/// <param name="ssInstanceState"></param>
		void MssRunInstance(string ssAccessKey, string ssSecretKey, string ssAmiId, string ssInstanceTypeName, string ssKeyName, string ssSecurityGroupId, string ssRegion, string ssInstanceTagName, out string ssInstanceId, out string ssInstanceState);

	} // IssAmazon_EC2_Utilities

} // OutSystems.NssAmazon_EC2_Utilities
