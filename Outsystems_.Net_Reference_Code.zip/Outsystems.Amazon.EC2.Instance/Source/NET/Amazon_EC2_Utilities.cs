using System;
using System.Collections;
using System.Data;
using OutSystems.HubEdition.RuntimePlatform;
using OutSystems.RuntimePublic.Db;
using Amazon;
using Amazon.EC2;
using Amazon.EC2.Model;
using System.Configuration;
using System.Collections.Generic;

namespace OutSystems.NssAmazon_EC2_Utilities
{

    public class CssAmazon_EC2_Utilities : IssAmazon_EC2_Utilities
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ssAccessKey"></param>
        /// <param name="ssSecretKey"></param>
        /// <param name="ssAmiId"></param>
        /// <param name="ssInstanceTypeName"></param>
        /// <param name="ssKeyName"></param>
        /// <param name="ssSecurityGroupId"></param>
        /// <param name="ssRegion"></param>
        /// <param name="ssInstanceTagName"></param>
        /// <param name="ssInstanceId"></param>
        /// <param name="ssInstanceState"></param>
        public void MssRunInstance(string ssAccessKey, string ssSecretKey, string ssAmiId, string ssInstanceTypeName, string ssKeyName, string ssSecurityGroupId, string ssRegion, string ssInstanceTagName, out string ssInstanceId, out string ssInstanceState)
        {

            var credentials = new Amazon.Runtime.BasicAWSCredentials(ssAccessKey, ssSecretKey);

            AmazonEC2Client ec2Client = new AmazonEC2Client(credentials, RegionEndpoint.GetBySystemName(ssRegion));

            //string amiID = "ami-cd293e27";
            //string keyPairName = "microsurv_private_kp";

            List<string> groups = new List<string>() { ssSecurityGroupId };
            var launchRequest = new RunInstancesRequest()
            {
                ImageId = ssAmiId,
                InstanceType = ssInstanceTypeName.ToLower(),
                MinCount = 1,
                MaxCount = 1,
                KeyName = ssKeyName,
                SecurityGroupIds = groups
            };

            var InstanceId = "";
            var StateName = "";
            var launchResponse = ec2Client.RunInstances(launchRequest);
            var instances = launchResponse.Reservation.Instances;
            var instanceIds = new List<string>();
            foreach (Instance item in instances)
            {
                instanceIds.Add(item.InstanceId);
                Console.WriteLine();
                Console.WriteLine("New instance: " + item.InstanceId);
                Console.WriteLine("Instance state: " + item.State.Name);
                Console.ReadLine();

                InstanceId = item.InstanceId;
                StateName = item.State.Name;
            }

            var response = ec2Client.CreateTags(new CreateTagsRequest
            {
                Resources = new List<string> {  InstanceId
            },
                Tags = new List<Tag> { new Tag {Key = "Name", Value = ssInstanceTagName}
                }
            });

            ssInstanceId = InstanceId;
            ssInstanceState = StateName;
            // TODO: Write implementation for action
        } // MssRunInstance


    } // CssAmazon_EC2_Utilities



} // OutSystems.NssAmazon_EC2_Utilities




